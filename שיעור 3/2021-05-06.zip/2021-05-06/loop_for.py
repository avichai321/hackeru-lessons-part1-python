print("into loop_for.py")

print("********** Example **********")
for i in range(1, 11):  # range(1,11) >>  1-10
    print(i)

print("********** Example **********")
for y in range(1, 11):
    print(11 - y)

print("********** Example **********")
for i in range(11):  # range(11) >>  0-10 >>
    print(i)

print("********** Example **********")
for i in "Gal Lavi hackeru":  # G,a,l, ,L,a,v,i
    print(i)


print("********** Example **********")
for i in range(1, 11, 2):  # range(1,11,2) >>  1-10 >> 1,3,5,7,9
    print(i)

print("********** Example **********")
for i in range(1, 11, 3):  # range(1,11,3) >>  1-10 >> 1,4,7,10
    print(i)


    
