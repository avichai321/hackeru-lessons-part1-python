
x = 100

def sayHolala():
    name = input('Enter name:')
    print('Holala ' + name)