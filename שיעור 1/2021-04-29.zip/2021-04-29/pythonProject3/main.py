'''
הערה של
יותר
משורה אחת
'''

print("Hola class")

# print('Gal')
print(10)

print('Hola')