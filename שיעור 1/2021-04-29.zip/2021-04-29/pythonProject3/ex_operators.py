print("into file operators")


# Ex1
print(10+3)


# Ex2
print(10-3)