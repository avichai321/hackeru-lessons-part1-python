print("into operators")

# Ex1
print(10+3)


# Ex2
print(10-3)



print(10)
print(10+3)
print(10-3)
print(10*3)
print(10/3)
print(10%3)

print("10" + "10") # "1010"
print(10 + 10) # 20
print("Hola" + ' ' + 'Class')


print("*******************")

print(10 > 3)
print(10 < 3)

print(10 > 10)
print(10 >= 10)

print(10 == 10)
print(10 != 10)


print("***********************")

print(10 > 5 or 10 < 6)
print(10 > 5 and 10 < 6)


