print("into file ")

first_name = "Gal"
last_name = 'Lavi'

full_name = first_name + " " + last_name #  "Gal"+ " " + "Lavi" >> "Gal Lavi"
print(full_name)
print(type(full_name))


num = 10
num = 20
print(num)
print( type(num) )


num1 = 10
num2 = 3.5


total = num1 + num2
print(total)
print(type(total))


x = 10 > 3
print(x)
print(type(x))


daniel = 10

print( type(daniel) )



f_name = input("Enter name"); # "Dani"
print(f_name)
print("Hola " + f_name) # "Hola " + "Dani" >> "Hola Dani"


n1 = input("Enter number1")
sum = int(n1) +10
print("sum is: " + str(sum) )

