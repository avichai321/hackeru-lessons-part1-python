print("into functions.py")
'''
what is functions?
how defined new function?
basic syntax >>  def function_name():
how to call function >> function_name()

'''
# Example
def sayHola():
    name = input("Enter name")
    print("Hola " + name)

sayHola()


# Example
def plus():
    num1 = input("Please enter num1 ")
    num1 = int(num1)
    num2 = input("Please enter num2 ")
    num2 = int(num2)
    print(num1+num2)

plus()
plus()
