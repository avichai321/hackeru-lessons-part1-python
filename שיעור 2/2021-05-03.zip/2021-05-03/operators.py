# operators
print("*********** 1 Operators ***********")
print(10+3)
print(10-3)
print(10*3)
print(10/3)
print(10%3)

print("*********** 2. Operators ***********")
print(10>3)
print(10<3)
print(10>=10)
print(10>10)
print(10!=3)
print(10==10)


print("*********** 3. Operators ***********")
print(10>3 and 10>20)
print(10>3 or 10>20)

print("*********** 4. Operators ***********")

num = 100
print(num)
num += 10  #num = num + 10
print(num)

num -= 10  # num = num - 10
print(num)

num *= 2  # num = num * 2
print(num)

num /= 2  # num = num / 2
print(num)
