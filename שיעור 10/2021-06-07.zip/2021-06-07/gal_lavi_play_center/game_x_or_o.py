

def play():
    print('play game X or O ..')