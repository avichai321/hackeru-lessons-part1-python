
def play():
    print('play oron game..')