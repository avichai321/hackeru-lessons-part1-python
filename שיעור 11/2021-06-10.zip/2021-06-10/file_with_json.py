import json
user_list = []

def add():
    item = input('Enter new item to list')
    user_list.append(item)

def print_list():
    if len(user_list) == 0:
        print('list empty !!!')
    else:
        for i in user_list:
            print(i)


def save_list_in_file():
    json_list = json.dumps(user_list)
    file = open('demo_files/file_with_josn.txt','w')
    file.write(json_list)
    file.close()

def read_list_fome_file():
    global user_list
    file = open('demo_files/file_with_josn.txt', 'r')
    json_list = file.read()
    user_list = json.loads(json_list)

def play():
    op = input('Enter option:'
                    ' | 1 - add to list'
                    ' | 2 - save list in file'
                    ' | 3 - read list form file'
                    ' | 100 - print list \n')
    if op == '0':
        return
    elif op == '1':
        add()
    elif op == '2':
        save_list_in_file()
    elif op == '3':
        read_list_fome_file()
    elif op == '100':
        print_list()
    play()

play()