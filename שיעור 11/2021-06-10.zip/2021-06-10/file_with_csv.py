print('into gal_csv.py')

import csv

# list of lists user
users = [["Gal", "gal@hackeru.co.il", "gal123"],
         ["Ben", "ben@gmail.com", "ben789"],
         ["Ran", "ran@gmail.com", "ranran4545"]]



print('*********** Ex 1 -  write to csv file  ***********')
file1 = open('demo_files/demo_file_for_excel.csv', 'w', newline='')  # without newline >> save one line empty
csv_ob1 = csv.writer(file1)
csv_ob1.writerow(["First Name","E-Mail","Password"])  # write one line on file..
for user in users:
    csv_ob1.writerow(user)  # take form list python  write one line on file..

file1.close()


print('*********** Ex 2 -  append to csv file  ***********')

with open('demo_files/demo_file_for_excel.csv', 'a') as file2:
    csv_ob2 = csv.writer(file2)
    csv_ob2.writerow(["Dana","dana@gmail.com","dada123456"])
    print(csv_ob2)
file2.close()


print('*********** Ex 3 -  read from csv file  ***********')

with open('demo_files/demo_file_for_excel.csv', 'r') as file3:
    csv_ob3 = csv.reader(file3)
    for i in csv_ob3:
        print(i)
file3.close()

