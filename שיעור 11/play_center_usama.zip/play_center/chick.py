import json
file = open("history_bank.json", "x")
file.close()
