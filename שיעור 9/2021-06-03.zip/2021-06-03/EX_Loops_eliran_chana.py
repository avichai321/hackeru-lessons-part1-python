print("********* #exLoops1 - For *********")

def exWhileLoop1():
    num = int(input("Enter number please loop ga: \n"))
    all_txt = ''
    for x in range(0, num):
        txt = input("Enter word please: \n")
        all_txt = all_txt + txt + " "
    print(all_txt)


# exWhileLoop1()

print("********* #exLoops1 - While *********")

def exWhileLoop2():
    num = int(input("Enter number please: \n"))
    i = 1
    all_txt = ''
    while i <= num:
        txt = input("Enter word please: \n")
        all_txt = all_txt + txt + " "
        i += 1
    else:
        print(all_txt)


# exWhileLoop2()

print("********* #exLoops2 - While *********")

def ex_while_loop_2():

    x = 1
    total = 0
    while x <= 5:
        price = int(input("Enter new price"))
        total += price
        x += 1
    print(total)


# ex_while_loop_2()

print("********* #exLoops2 - For *********")

def exercise2():
    total = 0
    for x in range(1, 6):
        price = int(input("Enter price "))
        total += price
    print(total)

# exercise2()

print("********* #exLoops3 - For *********")


def exercise3a():
    n = int(input("Enter Number to calculate please: \n"))
    x = 0
    for num in range(0, n + 1, 1):
        x = x + num
    print("You type this number:", n, "So the results of your number is: ", x)


# exercise3a()

print("********* #exLoops3 - While *********")


def exercise3b():
    num = int(input("Enter number please: \n"))
    x = 0
    while num >= 0:
        x += num
        num -= 1
    print("The score is =", x)


# exercise3b()


print("********* #exLoops4 - While *********")

def exloops4():
    price = int(input("Enter price: \n"))
    total_price = 0
    while price != 0:
        total_price += price
        price = int(input("enter price"))
    print(total_price)


# exloops4()


print("********* #exLoops4 - For *********")

def exloops4():
    z = [0]
    y = 0
    for i in z:
        z.append(i + 1)
        x = int(input("enter number"))
        if x != 0:
            y += x
        else:
            break
    print(y)
# exloops4()



def exloops5():

    """

    students = int( input("num of students on class:"))
    x = 1
    while x <= students:
        print('Chana ' , x)
        x += 1

    """


    print("********* #exLoops5 - While *********")
    studentnumber = int(input("Please enter students number: \n"))
    i = 1
    total = 0
    while i <= studentnumber:
        rank = int(input("Please enter students rank: \n"))
        total += rank
        i += 1

    z = total / studentnumber
    print("At the class have " + str(studentnumber) + " examined, and the average is " + str(z))


exloops5()


print("********* #exLoops5 - For *********")

def exloops5for():
    student_number = int(input("Enter the number of the students: \n"))
    y = 0
    avg = 0
    for i in range(student_number):
        y = int(input("Enter the rank of the students: \n"))
        avg += y
    avg /= student_number
    print("At the class " + str(student_number) + " examined, and the average rank is ", avg)


exloops5for()


print("********* #exLoops6 - While *********")

def loops6():
    student = int(input("Enter number of the students: \n"))
    i = 1
    top = 0
    while i <= student:
        grade = int(input("Enter the grade: \n"))
        if grade > top:
            top = grade
        i += 1
    print(student)


loops6()

print("********* #exLoops6 - for *********")

def exloops6for():
    student_number = int(input("Enter the number of the students: \n"))
    y = 0
    for i in range(student_number):
        rank = int(input("Enter the rank of the students: \n"))
        if y < rank:
            y = rank
    print("At the class " + str(student_number) + " examined, and the max rank is " + str(y))


exloops6for()


print("********* #exLoops7 - While *********")

def exloops7():
    studentnumber = int(input("Enter the number of the students: \n"))
    i = 1
    passes = 0
    loose = 0
    while i <= studentnumber:
        rank = int(input("Enter the rank of the students: \n"))
        if rank > 90:
            passes += 1
        elif rank < 70:
            loose += 1
        i += 1
    print("at the class " + str(studentnumber) + " examined, the pass students are " + str(passes) + " students, and the losers are " + str(loose) + " students.")


exloops7()


print("********* #exLoops7 - For *********")

def exloops7():
    studentnumber = int(input("Enter the number of the students: \n"))
    passes = 0
    loose = 0
    for i in range(studentnumber):
        rank = int(input("Enter the rank of the students: \n"))
        if rank > 90:
            passes += 1
        elif rank < 70:
            loose += 1
    print("at the class " + str(studentnumber) + " examined, the pass students are " + str(passes) + " students, and the losers are " + str(loose) + " students.")


exloops7()


print("********* #exLoops8 - While *********")

def exloops8():
    studentnumber = int(input("Enter the number of the students: \n"))
    i = 1
    passes = 0
    loose = 0
    while i <= studentnumber:
        rank = int(input("Enter the rank of the students: \n"))
        if rank > 90:
            passes += 1
        elif rank < 70:
            loose += 1
        i += 1
    if passes > loose:
        print("pass")
    else:
        print("lose")


exloops8()


print("********* #exLoops8 - For *********")

def exloops8():
    studentnumber = int(input("Enter the number of the students: \n"))
    passes = 0
    loose = 0
    for i in range(studentnumber):
        rank = int(input("Enter the rank of the students: \n"))
        if rank > 90:
            passes += 1
        elif rank < 70:
            loose += 1
    if passes > loose:
        print("pass")
    else:
        print("lose")


exloops8()

### done ### - hardest