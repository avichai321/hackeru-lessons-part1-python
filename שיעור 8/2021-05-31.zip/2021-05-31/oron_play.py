print('********* oron play *************')
import random

def sayHola():
    first = input("Enter first name")
    last = input('Enter last name')
    print("Hola " + first + " " + last)

def play_oron_plus():
    sayHola()
    num1 = random.randrange(1, 11)
    num2 = random.randrange(1, 11)
    user_sum = int(input(str(num1) + " + " +  str(num2) + " = "))
    if(user_sum == num1+num2):
        print('10 points')
        return True
    else:
        print('TRY again')
        return False


def play_oron_minus():
    sayHola()
    pass

play_oron_plus()