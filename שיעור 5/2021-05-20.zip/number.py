print("into number.py")

num1 = 10
print(num1)
print(type(num1))

num2 = 10.5
print(num2)
print(type(num2))

total = num1 + num2
print(total)
print(type(total))

print(" *********** random number ************")

import random
x = random.randrange(1, 101)  # between 1-100
print(x)

names = ["Gal", "Dan", "Ben","Yam"]

print(random.choice(names))  # get random value from the list



print(" *********** lambada ************")
# Lambda = use for anonymous function.

ex1 = lambda a : a + 2
print(ex1(5))  # 7


ex2 = lambda x, y : x + y
print(ex2(10, 5))  # 15

price_with_tax = lambda price : price + (price * 0.16)
print(price_with_tax(100)) # 116.0

